﻿namespace Lab2.Data
{
    public class DbContextOptions<T>
    {
    }
}