﻿namespace Lab2.Data
{
    public class ModelBuilder
    {
    }
}