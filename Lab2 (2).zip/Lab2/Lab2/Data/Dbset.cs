﻿namespace Lab2.Data
{
    public class Dbset<T>
    {
    }
}