﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lab2.Models;
using Microsoft.AspNetCore.Mvc;

namespace Lab2.Controllers
{
    public class CategoriesController : Controller
    {
        


        public IActionResult Index()
        {

            // okay here we display the view for 3 categories = model -> view
            // add items in the categories

            var categories = new List<Category>();
            for (var i =1; i < 10; i++)
            {
                categories.Add(new Category { Id = i, Name = "Category" + i.ToString() });
               
            }
        
            return View(categories);
        }

        public IActionResult Search(string categoryName)
        {
            // View.Bag come here
            ViewBag.categoryName = categoryName;

            
            // browse categories -> display view
            return View();
        }
        
        public IActionResult AddCategory()
        {
            // create a input form to add new categories
            return View();
        }

    }

     
}
